package atividadeumaula;

        
import java.util.Scanner;

public class Invoice {

    private int numeroFatura;
    private String descricaoItem;
    private int quantidade;
    private double preco;
    private double saldo;

    public Invoice(int numeroFatura, String descricaoItem, int quantidade, double preco, double saldo) {
        this.numeroFatura = numeroFatura;
        this.descricaoItem = descricaoItem;
        this.quantidade = quantidade;
        this.preco = preco;
        this.saldo = saldo;
    }

    public int getNumeroFatura() {
        return numeroFatura;
    }

    public void setNumeroFatura(int numeroFatura) {
        this.numeroFatura = numeroFatura;
    }

    public String getDescricaoItem() {
        return descricaoItem;
    }

    public void setDescricaoItem(String descricaoItem) {
        this.descricaoItem = descricaoItem;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
   
    public static void main(String[] args) {
        
        Invoice iv = new Invoice(1, "mouse", 0, 20, 100);
        
        iv.calculo();
    }
    
    public void calculo() {
    Scanner sc = new Scanner(System.in);
    
    double sal = this.getSaldo();
    double prec = this.getPreco();
    int quant = this.getQuantidade();
    
    System.out.println("Quantos mouses deseja? ");
    quant = sc.nextInt();
    
    double resultado = quant * prec;
    double saldoAtual = sal - resultado; 
    
    if (quant <= 0) {
        System.out.println("A quantidade não pode ser negativa ou zero.");
        return;
    }
    
    if (saldoAtual >= 0) {  
        System.out.println("Compra realizada, saldo total de: " + saldoAtual);
    } else { 
        System.out.println("Não foi possível realizar a compra");
    }
}

    }
package atividadejogodavelha;

public class AtividadeJogoDaVelha {
    
    public enum Numerador {
        V, 
        X, 
        O
    }
    
    private Numerador[][] grade;
    private Numerador playerAtual;

    public AtividadeJogoDaVelha() {
        this.grade = new Numerador[3][3];
        this.playerAtual = Numerador.X; // Começa com o jogador X
        inicializarGrade();
    }

    public void realizarJogada(int linha, int coluna) {
        if (linha >= 0 && linha < 3 && coluna >= 0 && coluna < 3 && grade[linha][coluna] == Numerador.V) {
            grade[linha][coluna] = playerAtual;
            alternarPlayer();
        } else {
            System.out.println("Jogada inválida. Tente novamente.");
        }
    }

    private void alternarPlayer() {
        playerAtual = (playerAtual == Numerador.X) ? Numerador.O : Numerador.X;
    }

    private void inicializarGrade() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grade[i][j] = Numerador.V;
            }
        }
    }

    public void exibirGrade() {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(converterGrade(grade[i][j]) + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    private char converterGrade(Numerador num) {
        switch (num) {
            case V:
                return ' ';
            case X:
                return 'X';
            case O:
                return 'O';
            default:
                return ' ';
        }
    }

    public boolean verificarVencedor() {
        // Verificar linhas e colunas
        for (int i = 0; i < 3; i++) {
            if (grade[i][0] == grade[i][1] && grade[i][1] == grade[i][2] && grade[i][0] != Numerador.V) {
                return true;
            }
            if (grade[0][i] == grade[1][i] && grade[1][i] == grade[2][i] && grade[0][i] != Numerador.V) {
                return true;
            }
        }
        // Verificar diagonais
        if ((grade[0][0] == grade[1][1] && grade[1][1] == grade[2][2] && grade[0][0] != Numerador.V) ||
            (grade[0][2] == grade[1][1] && grade[1][1] == grade[2][0] && grade[0][2] != Numerador.V)) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        AtividadeJogoDaVelha jogo = new AtividadeJogoDaVelha();
        jogo.exibirGrade();

        // Exemplo de jogadas
        jogo.realizarJogada(0, 0);
        jogo.exibirGrade();
        jogo.realizarJogada(1, 1);
        jogo.exibirGrade();
        jogo.realizarJogada(0, 1);
        jogo.exibirGrade();
        jogo.realizarJogada(2, 2);
        jogo.exibirGrade();
        jogo.realizarJogada(0, 2);
        jogo.exibirGrade();

        if (jogo.verificarVencedor()) {
            System.out.println("Temos um vencedor!");
        }
    }
}
